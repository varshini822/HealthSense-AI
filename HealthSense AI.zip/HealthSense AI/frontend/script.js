// Enhanced script.js with better authentication
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

function initializeApp() {
    setupNavigation();
    setupGetStartedButton();
    setupSymptomAnalysis();
    setupAuthForms();
    checkAuthStatus();
}

function setupNavigation() {
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const pageId = this.getAttribute('data-page');
            showPage(pageId);
        });
    });
}

function setupGetStartedButton() {
    const getStartedBtn = document.getElementById('get-started-btn');
    if (getStartedBtn) {
        getStartedBtn.addEventListener('click', function() {
            showPage('signup');
        });
    }
}

function setupSymptomAnalysis() {
    const analyzeBtn = document.getElementById('analyze-btn');
    if (analyzeBtn) {
        analyzeBtn.addEventListener('click', analyzeSymptoms);
    }
}

function setupAuthForms() {
    const loginForm = document.getElementById('login-form');
    const signupForm = document.getElementById('signup-form');
    
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    if (signupForm) {
        signupForm.addEventListener('submit', handleSignup);
    }
}

function checkAuthStatus() {
    const user = getUserData();
    if (user) {
        updateUIForUser(user);
        showPage('dashboard');
    } else {
        showPage('home');
    }
}

function getUserData() {
    const userData = localStorage.getItem('healthsense_user');
    return userData ? JSON.parse(userData) : null;
}

function showPage(pageId) {
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
    });
    
    const targetPage = document.getElementById(pageId);
    if (targetPage) {
        targetPage.classList.add('active');
        window.scrollTo(0, 0);
    }
}

function analyzeSymptoms() {
    const textarea = document.querySelector('textarea');
    const symptoms = textarea.value.trim().toLowerCase();
    const btn = document.getElementById('analyze-btn');
    
    if (!symptoms) {
        alert('Please describe your symptoms first');
        return;
    }
    
    // Show loading state
    const originalText = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Analyzing...';
    btn.disabled = true;
    
    // Simulate API call
    setTimeout(() => {
        const conditions = getConditionsBasedOnSymptoms(symptoms);
        updateSymptomResults(conditions);
        
        // Restore button
        btn.innerHTML = originalText;
        btn.disabled = false;
    }, 1500);
}

function getConditionsBasedOnSymptoms(symptoms) {
    let conditions = [];
    
    if (symptoms.includes('headache') && symptoms.includes('fever') && symptoms.includes('cough')) {
        conditions.push({name: 'Common cold', confidence: '75%'});
        conditions.push({name: 'Influenza (flu)', confidence: '65%'});
    } else if (symptoms.includes('headache') && symptoms.includes('fever')) {
        conditions.push({name: 'Common cold', confidence: '65%'});
        conditions.push({name: 'Sinus infection', confidence: '45%'});
    } else if (symptoms.includes('headache') && symptoms.includes('dizziness')) {
        conditions.push({name: 'Dehydration', confidence: '70%'});
        conditions.push({name: 'Migraine', confidence: '50%'});
    } else if (symptoms.includes('headache')) {
        conditions.push({name: 'Tension headache', confidence: '70%'});
        conditions.push({name: 'Dehydration', confidence: '40%'});
    } else if (symptoms.includes('fever')) {
        conditions.push({name: 'Viral infection', confidence: '60%'});
        conditions.push({name: 'Bacterial infection', confidence: '35%'});
    } else if (symptoms.includes('tired') || symptoms.includes('fatigue')) {
        conditions.push({name: 'Sleep deprivation', confidence: '55%'});
        conditions.push({name: 'Anemia', confidence: '30%'});
    } else if (symptoms.includes('nausea') && symptoms.includes('dizziness')) {
        conditions.push({name: 'Vertigo', confidence: '50%'});
        conditions.push({name: 'Inner ear infection', confidence: '45%'});
    }
    
    if (conditions.length === 0 && symptoms.length > 5) {
        conditions.push({name: 'General wellness advice recommended', confidence: 'N/A'});
    } else if (conditions.length === 0) {
        conditions.push({name: 'Please describe your symptoms in more detail', confidence: 'N/A'});
    }
    
    return conditions;
}

function updateSymptomResults(conditions) {
    const conditionList = document.querySelector('.condition-list');
    if (conditionList) {
        conditionList.innerHTML = '';
        
        conditions.forEach(condition => {
            const li = document.createElement('li');
            li.className = 'condition-item';
            li.innerHTML = `<span>${condition.name}</span><span class="confidence">${condition.confidence} match</span>`;
            conditionList.appendChild(li);
        });
    }
}

function handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    
    // Simple validation
    if (!email || !password) {
        alert('Please fill in all fields');
        return;
    }
    
    // In a real app, this would verify credentials with a server
    const user = getUserData();
    if (user && user.email === email) {
        showPage('dashboard');
    } else {
        alert('Invalid credentials. Please try again or sign up.');
    }
}

function handleSignup(e) {
    e.preventDefault();
    const name = document.getElementById('signup-name').value;
    const email = document.getElementById('signup-email').value;
    const password = document.getElementById('signup-password').value;
    const age = document.getElementById('signup-age').value;
    const gender = document.getElementById('signup-gender').value;
    
    // Simple validation
    if (!name || !email || !password || !age || !gender) {
        alert('Please fill in all fields');
        return;
    }
    
    const userData = { name, email, age, gender };
    localStorage.setItem('healthsense_user', JSON.stringify(userData));
    updateUIForUser(userData);
    showPage('dashboard');
}

function updateUIForUser(user) {
    const userNameElement = document.querySelector('.user-profile h3');
    if (userNameElement) {
        userNameElement.textContent = user.name;
    }
    
    const userAgeGender = document.querySelector('.user-profile p');
    if (userAgeGender) {
        userAgeGender.textContent = `Age: ${user.age} • ${user.gender.charAt(0).toUpperCase() + user.gender.slice(1)}`;
    }
}